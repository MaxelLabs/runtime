/**
 * passes/index.ts
 * 渲染通道模块导出
 */

export * from './render-pass-base';
export * from './opaque-pass';
export * from './transparent-pass';
